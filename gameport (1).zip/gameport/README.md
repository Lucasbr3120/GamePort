# GamePort

Fase 1: estrutura, identidade visual e navegação. Dados reais, Supabase e integrações chegam nas fases seguintes.

## Rodar no computador
    npm install
    npm run dev

## Gerar o APK (debug)
Use o workflow `build-apk.yml` no GitHub Actions. Ele roda `npm run build`, `npx cap add android` e `./gradlew assembleDebug`.
