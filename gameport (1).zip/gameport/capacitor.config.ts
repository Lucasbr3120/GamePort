import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'app.gameport.mobile',
  appName: 'GamePort',
  webDir: 'dist',
  backgroundColor: '#111318',
}
export default config
