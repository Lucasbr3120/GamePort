export type Compat = 'excelente' | 'boa' | 'parcial' | 'ruim' | 'incompativel' | 'nao-testado'

export const COMPAT_META: Record<Compat, { label: string; color: string }> = {
  excelente: { label: 'Excelente', color: '#36D69A' },
  boa: { label: 'Boa', color: '#3987FF' },
  parcial: { label: 'Parcial', color: '#F2C94C' },
  ruim: { label: 'Ruim', color: '#FF8A36' },
  incompativel: { label: 'Incompatível', color: '#F05B67' },
  'nao-testado': { label: 'Não testado', color: '#929BAA' },
}
