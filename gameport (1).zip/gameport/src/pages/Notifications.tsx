import { Bell } from 'lucide-react'
import EmptyState from '../components/EmptyState'

export default function Notifications() {
  return <EmptyState icon={Bell} title="Notificações" text="Você ainda não tem notificações. Elas chegam na Fase 6." action={{ label: 'Voltar ao início', to: '/' }} />
}
