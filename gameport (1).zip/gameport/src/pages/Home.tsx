import { Link } from 'react-router-dom'
import Skeleton from '../components/Skeleton'
import CompatBadge from '../components/CompatBadge'
import { COMPAT_META, type Compat } from '../types/compat'

export default function Home() {
  return (
    <div className="space-y-8">
      <section className="rounded-3xl border border-white/5 bg-gradient-to-br from-brand2 to-bg2 p-6">
        <h1 className="text-2xl font-extrabold leading-tight">Descubra o que roda no seu Android</h1>
        <p className="mt-2 text-sm text-fg/80">Benchmarks e configurações da comunidade para jogar jogos de PC e consoles no celular.</p>
        <Link to="/explorar" className="mt-5 inline-block rounded-xl bg-accent px-5 py-2.5 text-sm font-bold text-bg active:opacity-80">
          Explorar jogos
        </Link>
      </section>

      <section>
        <h2 className="mb-3 text-base font-bold">Como classificamos a compatibilidade</h2>
        <div className="flex flex-wrap gap-2">
          {(Object.keys(COMPAT_META) as Compat[]).map((c) => (
            <CompatBadge key={c} value={c} />
          ))}
        </div>
        <p className="mt-2 text-xs text-mute">Jogo sem testes aparece como "Não testado", nunca como incompatível.</p>
      </section>

      <section>
        <h2 className="mb-3 text-base font-bold">Em alta</h2>
        <div className="flex gap-3 overflow-x-auto">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-40 w-32 shrink-0" />
          ))}
        </div>
        <p className="mt-2 text-xs text-mute">O catálogo de jogos chega na Fase 2.</p>
      </section>
    </div>
  )
}
