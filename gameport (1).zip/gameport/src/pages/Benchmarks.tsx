import { BarChart3 } from 'lucide-react'
import EmptyState from '../components/EmptyState'

export default function Benchmarks() {
  return <EmptyState icon={BarChart3} title="Benchmarks" text="Publicação, comparação e gráficos de desempenho chegam na Fase 4." action={{ label: 'Voltar ao início', to: '/' }} />
}
