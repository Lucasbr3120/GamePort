import { useSearchParams } from 'react-router-dom'
import { Compass } from 'lucide-react'
import EmptyState from '../components/EmptyState'

export default function Explore() {
  const [params] = useSearchParams()
  const q = params.get('q')
  return (
    <EmptyState
      icon={Compass}
      title={q ? `Busca por "${q}"` : 'Explorar'}
      text="O catálogo de jogos, os filtros e a pesquisa chegam na Fase 2."
      action={{ label: 'Voltar ao início', to: '/' }}
    />
  )
}
