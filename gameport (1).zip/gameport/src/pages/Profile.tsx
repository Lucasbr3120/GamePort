import { User } from 'lucide-react'
import EmptyState from '../components/EmptyState'

export default function Profile() {
  return <EmptyState icon={User} title="Perfil" text="Perfis, conquistas e login chegam na Fase 6." action={{ label: 'Voltar ao início', to: '/' }} />
}
