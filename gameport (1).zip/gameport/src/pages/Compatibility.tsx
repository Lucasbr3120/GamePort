import { ShieldCheck } from 'lucide-react'
import EmptyState from '../components/EmptyState'

export default function Compatibility() {
  return <EmptyState icon={ShieldCheck} title="Compatibilidade" text="Meus dispositivos e o sistema de compatibilidade chegam na Fase 3." action={{ label: 'Voltar ao início', to: '/' }} />
}
