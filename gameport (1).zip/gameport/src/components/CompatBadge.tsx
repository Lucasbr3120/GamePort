import { COMPAT_META, type Compat } from '../types/compat'

export default function CompatBadge({ value }: { value: Compat }) {
  const { label, color } = COMPAT_META[value]
  return (
    <span
      className="rounded-full border px-2.5 py-0.5 text-xs font-semibold"
      style={{ color, borderColor: color + '55', background: color + '1a' }}
    >
      {label}
    </span>
  )
}
