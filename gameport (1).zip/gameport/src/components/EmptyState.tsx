import type { LucideIcon } from 'lucide-react'
import { Link } from 'react-router-dom'

type Props = { icon: LucideIcon; title: string; text: string; action?: { label: string; to: string } }

export default function EmptyState({ icon: Icon, title, text, action }: Props) {
  return (
    <div className="flex flex-col items-center rounded-3xl border border-white/5 bg-bg2 px-6 py-14 text-center">
      <div className="mb-4 grid size-14 place-items-center rounded-2xl bg-card text-brand">
        <Icon size={26} />
      </div>
      <h1 className="text-lg font-bold">{title}</h1>
      <p className="mt-1 max-w-xs text-sm text-mute">{text}</p>
      {action && (
        <Link to={action.to} className="mt-5 rounded-xl bg-brand px-5 py-2.5 text-sm font-semibold active:bg-brand2">
          {action.label}
        </Link>
      )}
    </div>
  )
}
