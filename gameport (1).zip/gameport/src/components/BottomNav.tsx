import { NavLink } from 'react-router-dom'
import { BarChart3, Compass, Home, ShieldCheck, User } from 'lucide-react'

const items = [
  { to: '/', label: 'Início', icon: Home },
  { to: '/explorar', label: 'Explorar', icon: Compass },
  { to: '/compatibilidade', label: 'Compatibilidade', icon: ShieldCheck },
  { to: '/benchmarks', label: 'Benchmarks', icon: BarChart3 },
  { to: '/perfil', label: 'Perfil', icon: User },
]

export default function BottomNav() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-white/5 bg-bg2/95 pb-[env(safe-area-inset-bottom)] backdrop-blur">
      <ul className="mx-auto flex max-w-3xl">
        {items.map(({ to, label, icon: Icon }) => (
          <li key={to} className="flex-1">
            <NavLink
              to={to}
              end={to === '/'}
              className={({ isActive }) =>
                `flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium transition-colors ${isActive ? 'text-brand' : 'text-mute'}`
              }
            >
              <Icon size={22} />
              {label}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  )
}
