import { useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Bell, Search, X } from 'lucide-react'

export default function TopBar() {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const navigate = useNavigate()

  function submit(e: FormEvent) {
    e.preventDefault()
    navigate(`/explorar?q=${encodeURIComponent(q.trim())}`)
    setOpen(false)
  }

  return (
    <header className="sticky top-0 z-20 border-b border-white/5 bg-bg/90 pt-[env(safe-area-inset-top)] backdrop-blur">
      {open ? (
        <form onSubmit={submit} className="flex items-center gap-2 px-4 py-3">
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar jogos"
            aria-label="Buscar jogos"
            className="h-10 flex-1 rounded-xl bg-card px-4 text-sm outline-none placeholder:text-mute focus:ring-2 focus:ring-brand"
          />
          <button type="button" onClick={() => setOpen(false)} aria-label="Fechar busca" className="grid size-10 place-items-center text-mute">
            <X size={20} />
          </button>
        </form>
      ) : (
        <div className="flex items-center justify-between px-4 py-3">
          <Link to="/" className="text-xl font-extrabold tracking-tight">
            Game<span className="text-brand">Port</span>
          </Link>
          <div className="flex items-center gap-1">
            <button onClick={() => setOpen(true)} aria-label="Buscar" className="grid size-10 place-items-center rounded-full active:bg-card">
              <Search size={20} />
            </button>
            <Link to="/notificacoes" aria-label="Notificações" className="grid size-10 place-items-center rounded-full active:bg-card">
              <Bell size={20} />
            </Link>
            <Link to="/perfil" aria-label="Perfil" className="ml-1 grid size-9 place-items-center rounded-full bg-brand2 text-sm font-bold">
              G
            </Link>
          </div>
        </div>
      )}
    </header>
  )
}
