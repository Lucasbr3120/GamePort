import { Outlet } from 'react-router-dom'
import TopBar from '../components/TopBar'
import BottomNav from '../components/BottomNav'

export default function AppLayout() {
  return (
    <div className="mx-auto flex min-h-screen max-w-3xl flex-col">
      <TopBar />
      <main className="flex-1 px-4 pb-28 pt-4">
        <Outlet />
      </main>
      <BottomNav />
    </div>
  )
}
