import { HashRouter, Navigate, Route, Routes } from 'react-router-dom'
import AppLayout from './layouts/AppLayout'
import Home from './pages/Home'
import Explore from './pages/Explore'
import Compatibility from './pages/Compatibility'
import Benchmarks from './pages/Benchmarks'
import Profile from './pages/Profile'
import Notifications from './pages/Notifications'

export default function App() {
  return (
    <HashRouter>
      <Routes>
        <Route element={<AppLayout />}>
          <Route index element={<Home />} />
          <Route path="explorar" element={<Explore />} />
          <Route path="compatibilidade" element={<Compatibility />} />
          <Route path="benchmarks" element={<Benchmarks />} />
          <Route path="perfil" element={<Profile />} />
          <Route path="notificacoes" element={<Notifications />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </HashRouter>
  )
}
